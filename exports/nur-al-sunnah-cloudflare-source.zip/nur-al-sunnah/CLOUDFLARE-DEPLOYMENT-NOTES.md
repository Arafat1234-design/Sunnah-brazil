# Nur Al-Sunnah — pacote completo do projeto

Este ZIP contém o código-fonte completo do projeto atual:

- Frontend React/Vite em `artifacts/openshelf`
- API Node/Express em `artifacts/api-server`
- Bibliotecas partilhadas em `lib`
- Configuração de workspace, scripts e schemas

## Importante para o Cloudflare

Este ZIP é um pacote de código-fonte. O upload direto em Cloudflare Pages não executa automaticamente a API, Clerk, PostgreSQL, uploads para Object Storage e rotas de Admin.

Para uma migração completa, o frontend deve ser publicado como Pages/Workers e a API deve ser publicada separadamente como Worker ou serviço compatível. As variáveis e segredos devem ser configurados no painel do Cloudflare/Replit, nunca colocados neste ZIP.

O Replit continua sendo o local de edição. Depois de cada edição, gere uma nova build e publique a versão correspondente no Cloudflare.
